/*
Author:     Oberon Ilano
Date:       08/27/2018
Purpose:    Chapter 1 Lab - Sammy's Motto - display motto on screen
 */
package sammysmotto2joptionpane;

import javax.swing.JOptionPane;
        
public class SammysMotto2JOptionPane 
    {
    public static void main(String[] args) 
        {
            JOptionPane.showMessageDialog(null, 
               "SSSSSSSSSSSSSSSSSSSSSSSSSS\n"
               +"S Sammy's makes it fun in the sun. S\n"
               + "SSSSSSSSSSSSSSSSSSSSSSSSSS");
        }
    }
