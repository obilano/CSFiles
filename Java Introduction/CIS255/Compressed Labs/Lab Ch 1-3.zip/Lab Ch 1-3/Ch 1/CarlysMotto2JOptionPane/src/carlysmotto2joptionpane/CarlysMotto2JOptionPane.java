/*
Author:     Oberon Ilano
Date:       08/27/2018
Purpose:    Chapter 1 Lab - Carly's Motto - display motto on screen
 */
package carlysmotto2joptionpane;

import javax.swing.JOptionPane;
        
public class CarlysMotto2JOptionPane 
    {
    public static void main(String[] args) 
        {
            JOptionPane.showMessageDialog(null, 
               "******************************************************\n"
               +"* Carly's makes the food that makes it a party.  *\n"
               + "******************************************************");
        }
    }